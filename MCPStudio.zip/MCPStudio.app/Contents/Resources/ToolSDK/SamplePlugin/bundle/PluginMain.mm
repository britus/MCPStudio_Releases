// ===================================================================
//  PluginMain.mm
//  MCPStudio - Custom Tool SDK - SamplePlugin
//
//  Created by EoF Software Lab on 2026.
//  Copyright © 2026 EoF Software Lab. All rights reserved.
// ===================================================================

#ifdef TOOL_BUNDLE

#import <Foundation/Foundation.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>

#include "CustomToolExports.h"
#include "ToolABI.h"

#include "ToolJSONBridge.h"

// MARK: Custom Tool Entry Point

#ifdef __cplusplus
extern "C" {
#endif

//clang: __attribute__((visibility("default")))
TOOL_API void toolEntry(const char* sid,            // AI client session ID
                        const char* toolName,       // Tooling name
                        const char* params,         // Tooling parameters
                        char** resultJson,          // Generated result as JSON
                        size_t* resultSize)         // Size of generated result
{
    if (!sid || !toolName || !params || !resultJson || !resultSize) {
        fprintf(stderr, "[SamplePlugin] Invalid parameters, abort!\n");
        return;
    }
    
    fprintf(stdout,
        "[SamplePlugin] Enter toolEntry function\nsid: %s\ntoolName: %s\nparams: %s",
        sid, toolName, params);
    
    const char* JSON_RESULT = "{\n"
        "\"structuredContent\" : {\n"
            "\"data\": \"Hello world from custom tool plugin!\",\n"
            "\"success\": true,\n"
            "\"error\": \"\"\n"
        "},\n"
        "\"content\": [{\n"
            "\"type\": \"text\",\n"
            "\"text\": \"Hello world from custom tool plugin!\"\n"
        "}]\n"
    "}\n";
    
    (*resultSize) = strlen(JSON_RESULT) + 1;
    (*resultJson) = (char*) malloc(*resultSize);
    
    strncpy((*resultJson), JSON_RESULT, (*resultSize));
}

#ifdef __cplusplus
}
#endif

#endif /* TOOL_BUNDLE */

