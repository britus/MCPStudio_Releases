// ===================================================================
//  ToolJSONBridge.mm
//  MCPStudio - Custom Tool SDK
//
//  Created by EoF Software Lab on 2026.
//  Copyright © 2026 EoF Software Lab. All rights reserved.
// ===================================================================
#import <Foundation/Foundation.h>
#import "ToolJSONBridge.h"

@implementation ToolJSONBridge

+ (NSDictionary *)parseJSON:(const char *)jsonCString
                      error:(NSError **)error
{
    if (!jsonCString) {
        return @{};
    }

    NSData *data = [NSData dataWithBytes:jsonCString
                                  length:strlen(jsonCString)];

    id obj = [NSJSONSerialization JSONObjectWithData:data
                                              options:0
                                                error:error];

    if (![obj isKindOfClass:[NSDictionary class]]) {
        return @{};
    }
    return obj;
}

@end
